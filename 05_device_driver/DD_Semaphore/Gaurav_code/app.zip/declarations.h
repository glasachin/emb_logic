#define NOF 7

int init();
extern void* mainMenu(void*);
extern void* openDevforRead(void*);
extern void* openDevforWrite(void*);
extern void* releaseDev(void*);
extern void* readDev(void*);
extern void* writeDev(void*);
extern void* exitApplication(void*);

extern void* (*fptr[NOF])(void*);

extern int readfd;
extern int writefd;
