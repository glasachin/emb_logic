#include"headers.h"
#include"operations.h"
static inline void unregister_chrdev(unsigned int major, const char* name)
{

}
